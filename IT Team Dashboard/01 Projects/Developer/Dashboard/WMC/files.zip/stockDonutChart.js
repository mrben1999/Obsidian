﻿import { formatNumberByLocale, escapeHtml, getEchartsLoadingOption } from '../wmchelpers.js';

/**
 * Component quản lý Biểu đồ Tròn (Donut/Pie) dùng chung cho dashboard WMC.
 *
 * Từ 07/2026: đây là nơi DUY NHẤT vẽ donut chart trên TV wall — bao gồm cả
 * "Stock by Customer" (customerChart) trước đây được vẽ trực tiếp bằng
 * initChart()/renderCustomerChart() ngay trong wmc.js. Việc gộp về 1 class
 * giúp logic tường minh, dễ bảo trì, và tái sử dụng được cho bất kỳ donut
 * chart nào phát sinh thêm sau này trên dashboard.
 *
 * @example Dùng đơn giản (không có label tổng ở giữa)
 *   const chart = new StockDonutChart('someDonutContainer');
 *   chart.render(apiData);
 *
 * @example Dùng cho "Stock by Customer" — có label TOTAL/số/đơn vị ở giữa,
 *          giống hệt giao diện gốc trên TV wall:
 *   const chart = new StockDonutChart('customerChart', {
 *       radius: ['50%', '80%'],
 *       center: ['32%', '50%'],
 *       legendRight: '0%',
 *       legendFontSize: 10,
 *       centerTotal: { label: 'TOTAL', unit: 'YDS' }
 *   });
 */
export default class StockDonutChart {
    /**
     * @param {string} containerId
     * @param {Object} [options]
     * @param {[string,string]} [options.radius=['50%','70%']] - bán kính trong/ngoài của donut
     * @param {[string,string]} [options.center=['40%','50%']] - tâm donut trong container
     * @param {string} [options.legendRight='5%'] - khoảng cách legend so với mép phải
     * @param {number} [options.legendFontSize=11] - cỡ chữ legend
     * @param {{label:string, unit:string}} [options.centerTotal] - nếu truyền vào, hiện
     *        tổng giá trị (tự tính từ data) ở giữa donut theo mẫu "TOTAL / 12,345 / YDS"
     */
    constructor(containerId, options = {}) {
        this.container = document.getElementById(containerId);
        this.chart = null;
        this.options = {
            radius: ['50%', '70%'],
            center: ['40%', '50%'],
            legendRight: '5%',
            legendFontSize: 11,
            centerTotal: null,
            ...options
        };
        this.init();
    }

    init() {
        if (!this.container) return;
        this.chart = echarts.init(this.container);
        this.showLoading();
    }

    showLoading() {
        if (!this.chart) return;
        // Dùng option loading DÙNG CHUNG cho toàn dashboard (wmchelpers.js) —
        // không tự định nghĩa màu/opacity/text riêng ở đây nữa. Chỉ hiện đúng
        // 1 vòng tròn xoay, không kèm chữ, đồng nhất với mọi chart/bảng khác.
        this.chart.showLoading(getEchartsLoadingOption());
    }

    hideLoading() {
        if (this.chart) this.chart.hideLoading();
    }

    /**
     * Hiển thị trạng thái lỗi khi API thất bại (message đã được escapeHtml)
     */
    showError(message) {
        this.hideLoading();
        const safeMessage = escapeHtml(message || 'Lỗi tải dữ liệu');

        this.container.innerHTML = `
            <div class="chart-error-state" style="display:flex; flex-direction:column; align-items:center; justify-content:center; height:100%; color:var(--red);">
                <i class="bi bi-exclamation-triangle" style="font-size: 2rem;"></i>
                <p style="font-size: 12px; margin-top: 8px;">${safeMessage}</p>
                <button class="btn btn-sm btn-outline-secondary retry-btn" style="font-size:10px; color:#fff; border-color:var(--border-color);">Thử lại</button>
            </div>
        `;
    }

    /**
     * Chuẩn hoá 1 phần tử dữ liệu về đúng định dạng ECharts pie {value, name, itemStyle}.
     * Tự nhận diện 2 định dạng đầu vào phổ biến trong hệ thống:
     *  - Đã đúng chuẩn ECharts: { value, name, itemStyle: { color } }  (vd: customerStocks)
     *  - Dữ liệu thô dạng report: { quantity, categoryName, colorHex }
     */
    _normalizeItem(item) {
        if (item && typeof item.value !== 'undefined' && typeof item.name !== 'undefined') {
            return item;
        }
        return {
            value: item.quantity,
            name: item.categoryName,
            itemStyle: { color: item.colorHex || '#5a67d8' }
        };
    }

    /**
     * Render dữ liệu vào biểu đồ
     * @param {Array} data - Mảng dữ liệu từ API trả về
     */
    render(data) {
        if (!this.chart) return;
        this.hideLoading();

        if (!data || data.length === 0) {
            this.chart.clear();
            this.container.innerHTML = `<div class="empty-state" style="text-align:center; padding-top:20%;">No Data Available</div>`;
            return;
        }

        const normalizedData = data.map(item => this._normalizeItem(item));

        const option = {
            tooltip: {
                trigger: 'item',
                backgroundColor: '#0d2857',
                borderColor: '#8ba2c1',
                borderWidth: 1,
                textStyle: { color: '#ffffff' },
                // escapeHtml phòng ngừa XSS trong trường hợp ECharts render HTML chuỗi
                formatter: params => {
                    const safeName = escapeHtml(params.name);
                    const formattedValue = formatNumberByLocale(params.value);
                    return `${safeName}: <b>${formattedValue}</b> (${params.percent}%)`;
                }
            },
            legend: {
                orient: 'vertical',
                right: this.options.legendRight,
                top: 'center',
                textStyle: { color: '#8ba2c1', fontSize: this.options.legendFontSize }
            },
            series: [
                {
                    name: 'Stock Status',
                    type: 'pie',
                    radius: this.options.radius,
                    center: this.options.center,
                    avoidLabelOverlap: false,
                    label: { show: false },
                    emphasis: {
                        label: { show: true, fontSize: '14', fontWeight: 'bold', color: '#fff' }
                    },
                    data: normalizedData
                }
            ]
        };

        // Nếu được cấu hình centerTotal -> hiện "TOTAL / giá trị / đơn vị" ở giữa donut
        // (giữ nguyên style của bản gốc customerChart trên TV wall)
        if (this.options.centerTotal) {
            const { label, unit } = this.options.centerTotal;
            const totalValue = normalizedData
                .reduce((sum, d) => sum + (Number(d.value) || 0), 0)
                .toLocaleString('en-US');

            option.title = {
                text: `{a|${label}}\n{b|${totalValue}}\n{c|${unit}}`,
                left: this.options.center[0],
                top: this.options.center[1],
                textAlign: 'center',
                textStyle: {
                    rich: {
                        a: { color: '#8ba2c1', fontSize: 12, padding: [0, 0, 4, 0] },
                        b: { color: '#fff', fontSize: 18, fontWeight: 'bold', padding: [4, 0, 4, 0] },
                        c: { color: '#8ba2c1', fontSize: 12, padding: [4, 0, 0, 0] }
                    }
                }
            };
        }

        // notMerge:true — mỗi lần refresh dashboard thay toàn bộ dataset, không patch từng phần
        this.chart.setOption(option, true);
    }

    resize() {
        if (this.chart) {
            this.chart.resize();
        }
    }
}