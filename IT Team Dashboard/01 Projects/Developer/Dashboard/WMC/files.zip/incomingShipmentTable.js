﻿import { formatNumberByLocale, getCurrentLanguage, escapeHtml, getLoadingHtml } from '../wmchelpers.js';

/**
 * Component quản lý Bảng Giám sát Hàng đang vận chuyển (WMC Enterprise Incoming Shipment)
 */
export default class IncomingShipmentTable {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        this.rawData = [];
        this.currentPage = 1;
        this.pageSize = 7; // Số dòng trên một trang để giao diện gọn gàng
        this.autoPlayTimer = null;
        this.intervalTime = 300000;

        this.localizeDict = {
            vi: {
                cus: "CUS", packingList: "PACKING LIST", supp: "SUPP", eta: "ETA", qty: "QTY (YDS)", status: "STATUS",
                loading: "Đang tải dữ liệu vận chuyển...",
                empty: "Không có lô hàng nào đang vận chuyển.",
                page: "Trang"
            },
            en: {
                cus: "CUS", packingList: "PACKING LIST", supp: "SUPP", eta: "ETA", qty: "QTY (YDS)", status: "STATUS",
                loading: "Loading shipments...",
                empty: "No incoming shipments in transit.",
                page: "Page"
            }
        };

        window.addEventListener('wmc-language-changed', () => {
            if (this.rawData.length > 0) this.render(this.rawData);
        });
    }

    _t(key) {
        const lang = getCurrentLanguage() || 'vi';
        return this.localizeDict[lang][key] || this.localizeDict['en'][key] || key;
    }

    showLoading() {
        if (!this.container) return;
        this.stopAutoPlay();
        // Chỉ hiện vòng tròn xoay dùng chung, không kèm chữ — đồng nhất với
        // mọi chart ECharts khác trên dashboard.
        this.container.innerHTML = getLoadingHtml();
    }

    showError(msg) {
        if (!this.container) return;
        this.stopAutoPlay();
        const safeMsg = escapeHtml(msg || '');
        this.container.innerHTML = `
            <div style="text-align:center; padding: 30px; color: var(--red); font-size:12px;">
                <i class="bi bi-exclamation-diamond-fill fs-5 mb-1"></i>
                <div>Lỗi nạp Grid Vận chuyển</div>
                <small class="text-muted d-block">${safeMsg}</small>
            </div>
        `;
    }

    render(apiResponse) {
        if (!this.container) return;

        let data = [];
        if (apiResponse) {
            if (Array.isArray(apiResponse)) data = apiResponse;
            else if (apiResponse.data && Array.isArray(apiResponse.data)) data = apiResponse.data;
        }
        this.rawData = data;

        if (data.length === 0) {
            this.stopAutoPlay();
            this.container.innerHTML = `
                <div style="text-align:center; padding: 40px; color: var(--text-sub); font-size:12px;">
                    ${this._t('empty')}
                </div>
            `;
            return;
        }

        const totalPages = Math.ceil(this.rawData.length / this.pageSize);
        if (this.currentPage > totalPages) this.currentPage = 1;

        const startIndex = (this.currentPage - 1) * this.pageSize;
        const pagedData = this.rawData.slice(startIndex, startIndex + this.pageSize);

        // TỐI ƯU: dựng mảng các đoạn HTML rồi join() 1 lần thay vì += lặp lại
        // (tránh tạo chuỗi trung gian mới ở mỗi vòng lặp).
        const rowsHtml = pagedData.map(item => {
            let badgeColor = 'var(--blue)';
            if (item.status === "Late") badgeColor = 'var(--red)';
            else if (item.status === "Arrived") badgeColor = 'var(--green)';
            else if (item.status === "In Transit") badgeColor = 'var(--orange)';

            const rowStyle = item.isSupplierHighRisk
                ? `style="background: linear-gradient(90deg, rgba(255, 61, 0, 0.15) 0%, rgba(4, 20, 50, 0.2) 100%); font-weight: 500;"`
                : '';

            const suppStyle = item.isSupplierHighRisk
                ? `style="color: var(--red); font-weight: bold; text-decoration: underline;" title="High Delay Risk Supplier!"`
                : '';

            // ĐÃ KHẮC PHỤC (đồng bộ với stockDonutChart.js): escapeHtml cho toàn bộ
            // trường text đến từ API trước khi chèn vào innerHTML, phòng XSS.
            const customer = escapeHtml(item.customer || '-');
            const packingList = escapeHtml(item.packingList || '-');
            const supplier = escapeHtml(item.supplier || '-');
            const eta = escapeHtml(item.eta || '-');
            const status = escapeHtml(item.status || '-');

            return `
                <tr ${rowStyle}>
                    <td style="text-align: left; padding: 6px 6px; font-size: 14px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${customer}</td>
                    <td style="text-align: left; padding: 6px 6px; font-size: 14px; font-family: monospace; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; color: #e0e6ed;">${packingList}</td>
                    <td ${suppStyle} style="text-align: left; padding: 6px 6px; font-size: 14px;">${supplier} ${item.isSupplierHighRisk ? '⚠' : ''}</td>
                    <td style="text-align: center; padding: 6px 6px; font-size: 14px; color: var(--text-sub);">${eta}</td>
                    <td style="text-align: right; padding: 6px 6px; font-size: 14px; font-family: monospace; color: #fff;">${formatNumberByLocale(item.qty, 2)}</td>
                    <td style="text-align: center; padding: 6px 6px; font-size: 14px;">
                        <span style="display: inline-flex; align-items: center; gap: 5px;">
                            <span style="width: 8px; height: 8px; border-radius: 50%; background-color: ${badgeColor}; display: inline-block; box-shadow: 0 0 6px ${badgeColor};"></span>
                            <small style="color: ${badgeColor}; font-weight: bold; font-size: 14px;">${status}</small>
                        </span>
                    </td>
                </tr>
            `;
        }).join('');

        // Dựng sẵn dãy chấm phân trang bằng mảng + join thay vì map().join() lồng trực tiếp trong template
        const pageDotsHtml = Array.from({ length: totalPages }, (_, i) => i + 1)
            .map(p => `<span style="width: ${p === this.currentPage ? '18px' : '6px'}; height: 6px; border-radius: 3px; background-color: ${p === this.currentPage ? 'var(--blue)' : 'rgba(139, 162, 193, 0.3)'}; transition: all 0.3s ease;"></span>`)
            .join('');

        const html = `
            <div class="table-responsive" style="border: 1px solid var(--border-color); border-radius: 4px; overflow: hidden;">
                <table class="table table-dark table-hover m-0" style="table-layout: fixed; width: 100%;">
                    <thead>
                        <tr style="background-color: var(--card-bg); box-shadow: inset 0 -1px 0 var(--border-color);">
                            <th style="width: 12%; text-align: left; color: var(--text-sub); font-size: 14px; padding: 6px 6px;">${this._t('cus')}</th>
                            <th style="width: 16%; text-align: left; color: var(--text-sub); font-size: 14px; padding: 6px 6px;">${this._t('packingList')}</th>
                            <th style="width: 15%; text-align: left; color: var(--text-sub); font-size: 14px; padding: 6px 6px;">${this._t('supp')}</th>
                            <th style="width: 22%; text-align: center; color: var(--text-sub); font-size: 14px; padding: 6px 6px;">${this._t('eta')}</th> 
                            <th style="width: 20%; text-align: right; color: var(--text-sub); font-size: 14px; padding: 6px 6px;">${this._t('qty')}</th>
                            <th style="width: 15%; text-align: center; color: var(--text-sub); font-size: 14px; padding: 6px 6px;">${this._t('status')}</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${rowsHtml}
                    </tbody>
                </table>
            </div>
            <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 6px; padding: 0 4px;">
                <div style="font-size: 11px; color: var(--text-sub);">Total: <b>${this.rawData.length}</b> shipments</div>
                <div style="display: flex; gap: 4px; align-items: center;">
                    <span style="font-size: 11px; color: var(--text-sub);">${this._t('page')} ${this.currentPage} / ${totalPages}</span>
                    ${pageDotsHtml}
                </div>
            </div>
            
        `;

        this.container.innerHTML = html;
        this.startAutoPlay(totalPages);
    }

    startAutoPlay(totalPages) {
        this.stopAutoPlay();
        if (totalPages <= 1) return;
        this.autoPlayTimer = setInterval(() => {
            this.currentPage = (this.currentPage >= totalPages) ? 1 : this.currentPage + 1;
            this.render(this.rawData);
        }, this.intervalTime);
    }

    stopAutoPlay() {
        if (this.autoPlayTimer) {
            clearInterval(this.autoPlayTimer);
            this.autoPlayTimer = null;
        }
    }
}