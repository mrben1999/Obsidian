﻿import { formatNumberByLocale, escapeHtml, getEchartsLoadingOption } from '../wmchelpers.js';

/**
 * Component quản lý Biểu đồ Hiệu suất Nhà cung cấp (WMC Stacked Bar Chart)
 */
export default class SupplierPerformanceChart {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        this.chart = null;
        this.init();
    }

    init() {
        if (!this.container) return;
        this.chart = echarts.init(this.container);
        this.showLoading();
    }

    showLoading() {
        if (!this.chart) return;
        // Chỉ hiện vòng tròn xoay dùng chung, không kèm chữ — đồng nhất với
        // mọi chart/bảng khác trên dashboard.
        this.chart.showLoading(getEchartsLoadingOption());
    }

    hideLoading() {
        if (this.chart) this.chart.hideLoading();
    }

    showError(msg) {
        this.hideLoading();
        const safeMsg = escapeHtml(msg || 'Chart Error');
        this.container.innerHTML = `
            <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; height:100%; color:var(--red); font-size:12px;">
                <i class="bi bi-exclamation-octagon-fill mb-1"></i>
                <span>${safeMsg}</span>
            </div>
        `;
    }

    render(apiResponse) {
        if (!this.chart || !this.container) return;
        this.hideLoading();

        let data = [];
        if (apiResponse) {
            if (Array.isArray(apiResponse)) data = apiResponse;
            else if (apiResponse.data && Array.isArray(apiResponse.data)) data = apiResponse.data;
        }

        if (!data || data.length === 0) {
            this.container.innerHTML = `<div style="text-align:center; padding-top:20%; color:var(--text-sub); font-size:12px;">No Performance Data</div>`;
            return;
        }

        // Lọc lấy 15 Supplier có record đơn hàng nhiều nhất
        const topSuppliersData = [...data]
            .sort((a, b) => (b.totalOrders || 0) - (a.totalOrders || 0))
            .slice(0, 15);

        const chartData = topSuppliersData.reverse();
        const categories = chartData.map(item => item.supplier || '-');
        const earlySeries = chartData.map(item => item.earlyCount || 0);
        const onTimeSeries = chartData.map(item => item.onTimeCount || 0);
        const delayedSeries = chartData.map(item => item.delayedCount || 0);

        // Lấy mã màu thực tế từ biến CSS hệ thống
        const computedStyle = getComputedStyle(document.documentElement);
        const colorGreen = computedStyle.getPropertyValue('--green').trim() || '#2ecc71';
        const colorBlue = computedStyle.getPropertyValue('--blue').trim() || '#3498db';
        const colorRed = computedStyle.getPropertyValue('--red').trim() || '#e74c3c';
        const colorBorder = computedStyle.getPropertyValue('--border-color').trim() || '#102a57';

        // TỐI ƯU: dựng sẵn Set các supplier high-risk (tra cứu O(1)) thay vì
        // gọi Array.find() bên trong axisLabel.formatter — formatter này được
        // ECharts gọi lại mỗi lần vẽ/redraw/resize cho từng nhãn trục Y.
        const highRiskSet = new Set(
            data.filter(i => i.isHighRisk).map(i => i.supplier)
        );

        const option = {
            backgroundColor: 'transparent',
            tooltip: {
                trigger: 'axis',
                axisPointer: { type: 'shadow' },
                backgroundColor: 'var(--card-bg)',
                borderColor: 'var(--border-color)',
                textStyle: { color: '#fff', fontSize: 12 },
                formatter: function (params) {
                    const safeCategoryName = escapeHtml(params[0].name);
                    let res = `<b>${safeCategoryName}</b><br/>`;
                    params.forEach(p => {
                        res += `${p.marker} ${p.seriesName}: <b>${p.value}</b> orders<br/>`;
                    });
                    return res;
                }
            },
            legend: {
                data: ['Giao Sớm / Early', 'Đúng Hạn / On Time', 'Trễ Hạn / Delayed'],
                top: '0%',
                textStyle: { color: '#8ba2c1', fontSize: 11 }
            },
            grid: {
                left: '4%',
                right: '6%',
                bottom: '5%',
                top: '12%',
                containLabel: true
            },
            xAxis: {
                type: 'value',
                axisLabel: { color: '#8ba2c1', fontSize: 10 },
                splitLine: { lineStyle: { color: 'rgba(13, 40, 87, 0.4)', type: 'dashed' } }
            },
            yAxis: {
                type: 'category',
                data: categories,
                axisLabel: {
                    color: '#ffffff',
                    fontSize: 11,
                    rich: {
                        highRiskIcon: { color: '#ff3d00', fontWeight: 'bold' } // Chỉ đỏ icon
                    },
                    formatter: function (value) {
                        if (highRiskSet.has(value)) {
                            return `${value} {highRiskIcon|⚠}`; // Tên chữ ăn theo color: '#ffffff' mặc định, icon ăn màu đỏ
                        }
                        return value;
                    }
                },
                axisLine: { lineStyle: { color: colorBorder } }
            },
            series: [
                {
                    name: 'Giao Sớm / Early',
                    type: 'bar',
                    stack: 'total',
                    label: { show: true, position: 'inside', formatter: val => val.value > 0 ? val.value : '' },
                    itemStyle: { color: colorGreen },
                    data: earlySeries
                },
                {
                    name: 'Đúng Hạn / On Time',
                    type: 'bar',
                    stack: 'total',
                    label: { show: true, position: 'inside', formatter: val => val.value > 0 ? val.value : '' },
                    itemStyle: { color: colorBlue },
                    data: onTimeSeries
                },
                {
                    name: 'Trễ Hạn / Delayed',
                    type: 'bar',
                    stack: 'total',
                    label: { show: true, position: 'inside', formatter: val => val.value > 0 ? val.value : '' },
                    itemStyle: { color: colorRed },
                    data: delayedSeries
                }
            ]
        };

        this.chart.setOption(option, true);
    }

    resize() {
        if (this.chart) this.chart.resize();
    }
}