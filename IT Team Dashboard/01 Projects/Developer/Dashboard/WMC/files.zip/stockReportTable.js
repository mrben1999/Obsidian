﻿import {
    formatNumberByLocale,
    getCurrentLanguage,
    escapeHtml,
    getLoadingHtml
} from '../wmchelpers.js';

/**
 * Component quản lý Bảng Báo cáo Tồn kho Khách hàng & Mùa vụ (WMC Enterprise v3.1)
 * Chức năng nâng cao: Cố định Header, Phân trang tự động xoay tua (Auto-Carousel), Căn chỉnh chuẩn UI.
 */
export default class StockReportTable {
    /**
     * @param {string} containerId - ID của thẻ div bọc bảng trên Index.cshtml
     */
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        this.rawData = []; // Lưu trữ dữ liệu gốc từ API

        // --- CẤU HÌNH PHÂN TRANG & AUTO RUN ---
        this.currentPage = 1;
        this.pageSize = 8; // Số dòng hiển thị trên một trang (Anh có thể chỉnh lại cho vừa khít màn hình TV)
        this.autoPlayTimer = null;
        this.intervalTime = 7000; // Thời gian tự động chuyển trang: 7 giây (7000ms)

        // Bộ từ điển dịch thuật nội bộ
        this.localizeDict = {
            vi: {
                custCode: "Mã KH",
                custName: "Tên Khách Hàng",
                season: "Mùa Vụ",
                rcvQty: "SL Nhập",
                issQty: "SL Xuất",
                stkQty: "SL Tồn",
                issRate: "Tỷ Lệ Xuất",
                summary: "Tổng Bình Quân",
                loading: "Đang tải dữ liệu...",
                error: "Không thể kết nối API Báo cáo tồn kho",
                retry: "Thử lại hệ thống",
                empty: "Không tìm thấy dữ liệu xuất nhập tồn kho hợp lệ.",
                page: "Trang"
            },
            en: {
                custCode: "Cust Code",
                custName: "Customer Name",
                season: "Season",
                rcvQty: "Recv Qty",
                issQty: "Iss Qty",
                stkQty: "Stock Qty",
                issRate: "Iss Rate",
                summary: "Average Total",
                loading: "Loading data...",
                error: "Cannot connect to Stock Report API",
                retry: "Retry System",
                empty: "No valid inventory data found.",
                page: "Page"
            }
        };

        // Lắng nghe sự kiện đổi ngôn ngữ toàn cục để dịch bảng ngay lập tức
        window.addEventListener('wmc-language-changed', () => {
            if (this.rawData && this.rawData.length > 0) {
                this.render(this.rawData);
            }
        });
    }

    /**
     * Hàm lấy chuỗi ngôn ngữ hiện tại (vi/en)
     */
    _t(key) {
        const lang = getCurrentLanguage() || 'vi';
        return this.localizeDict[lang][key] || this.localizeDict['en'][key] || key;
    }

    showLoading() {
        if (!this.container) return;
        this.stopAutoPlay(); // Dừng chạy ngầm khi đang load
        // Chỉ hiện vòng tròn xoay dùng chung, không kèm chữ — đồng nhất với
        // mọi chart ECharts khác trên dashboard (StockDonutChart, SupplierPerformanceChart...).
        this.container.innerHTML = getLoadingHtml();
    }

    showError(msg) {
        if (!this.container) return;
        this.stopAutoPlay();
        const safeMsg = escapeHtml(msg || '');
        this.container.innerHTML = `
            <div class="table-error-state" style="text-align:center; padding: 40px; color: var(--red);">
                <i class="bi bi-exclamation-triangle-fill fs-3 mb-2"></i>
                <div>${this._t('error')}</div>
                <small class="text-muted d-block mb-3">${safeMsg}</small>
                <button class="btn btn-outline-danger btn-sm" onclick="location.reload()">${this._t('retry')}</button>
            </div>
        `;
    }

    /**
     * Hàm render chính - Nhận dữ liệu thô và tiến hành phân bổ giao diện
     */
    render(apiResponse) {
        if (!this.container) return;

        // Bóc tách dữ liệu phòng vệ (unwrap) từ các định dạng API khác nhau
        let data = [];
        if (apiResponse) {
            if (Array.isArray(apiResponse)) data = apiResponse;
            else if (apiResponse.data && Array.isArray(apiResponse.data)) data = apiResponse.data;
            else if (apiResponse.isSuccess && Array.isArray(apiResponse.data)) data = apiResponse.data;
        }

        this.rawData = data; // Lưu lại để dùng khi chuyển trang hoặc đổi ngôn ngữ

        if (data.length === 0) {
            this.stopAutoPlay();
            this.container.innerHTML = `
                <div class="table-empty-state" style="text-align:center; padding: 40px; color: var(--text-sub);">
                    <i class="bi bi-inbox fs-3 d-block mb-2"></i>
                    ${this._t('empty')}
                </div>
            `;
            return;
        }

        // Tính toán tổng số trang dựa trên độ dài dữ liệu
        const totalPages = Math.ceil(this.rawData.length / this.pageSize);

        // Phòng vệ nếu trang hiện tại vượt quá tổng số trang do dữ liệu co giãn
        if (this.currentPage > totalPages) this.currentPage = 1;

        // Cắt mảng dữ liệu chỉ lấy phạm vi của trang hiện tại
        const startIndex = (this.currentPage - 1) * this.pageSize;
        const endIndex = startIndex + this.pageSize;
        const pagedData = this.rawData.slice(startIndex, endIndex);

        // TỐI ƯU: dựng mảng đoạn HTML rồi join() 1 lần thay vì += lặp lại nhiều lần
        const rowsHtml = pagedData.map(item => {
            const rcv = item.rcvQty || 0;
            const iss = item.issQty || 0;
            const stk = item.stockQty || 0;
            const rate = item.issRate || 0;

            // Xác định màu sắc động cho cột tỷ lệ tiến độ
            let rateColor = 'var(--blue)';
            if (rate >= 100) rateColor = 'var(--green)';
            else if (rate > 50) rateColor = 'var(--orange)';
            else if (rate > 0) rateColor = 'var(--red)';

            // ĐÃ KHẮC PHỤC (đồng bộ với stockDonutChart.js): escapeHtml cho các
            // trường text đến từ API trước khi chèn vào innerHTML, phòng XSS.
            const customer = escapeHtml(item.customer || '-');
            const season = escapeHtml(item.season || '-');

            return `
                <tr style="border-bottom: 1px solid rgba(13, 40, 87, 0.5);">
                    <td style="text-align: left;   padding: 6px 6px; font-size: 16px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${customer}">${customer}</td>
                    <td style="text-align: left;   padding: 6px 6px; font-size: 16px; color: var(--text-sub);">${season}</td>
                    <td style="text-align: right;  padding: 6px 6px; font-size: 16px; font-family: monospace; color: #fff;">${formatNumberByLocale(rcv, 0)}</td>
                    <td style="text-align: right;  padding: 6px 6px; font-size: 16px; font-family: monospace; color: var(--orange);">${formatNumberByLocale(iss, 0)}</td>
                    <td style="text-align: right;  padding: 6px 6px; font-size: 16px; font-family: monospace; color: var(--green);">${formatNumberByLocale(stk, 0)}</td>
                    <td style="text-align: right; padding: 6px 6px; font-size: 16px;">
                        <div style="display: flex; align-items: center; justify-content: flex-end; gap: 8px;">
                            <div style="width: 50px; background: rgba(255,255,255,0.1); height: 6px; border-radius: 3px; overflow: hidden; display: inline-block;">
                                <div style="width: ${Math.min(rate, 100)}%; background-color: ${rateColor}; height: 100%;"></div>
                            </div>
                            <span style="font-family: monospace; font-weight: bold; color: ${rateColor}; min-width: 42px; display: inline-block;">
                                ${formatNumberByLocale(rate, 0)}%
                            </span>
                        </div>
                    </td>
                </tr>
            `;
        }).join('');

        // Dựng sẵn dãy chấm phân trang bằng mảng + join thay vì map().join() lồng trực tiếp trong template
        const pageDotsHtml = Array.from({ length: totalPages }, (_, i) => i + 1)
            .map(p => `<span style="width: ${p === this.currentPage ? '18px' : '6px'}; height: 6px; border-radius: 3px; background-color: ${p === this.currentPage ? 'var(--blue)' : 'rgba(139, 162, 193, 0.3)'}; transition: all 0.3s ease;"></span>`)
            .join('');

        const html = `
            <div class="table-responsive" style="max-height: 480px; overflow-y: auto; border: 1px solid var(--border-color); border-radius: 6px; position: relative;">
                <table class="table table-dark table-hover m-0" style="table-layout: fixed; width: 100%; border-collapse: separate; border-spacing: 0;">
                    <thead>
                        <tr style="position: sticky; top: 0; z-index: 10; background-color: var(--card-bg); box-shadow: inset 0 -2px 0 var(--border-color);">
                            <th style="width: 10%; text-align: left;   color: var(--text-sub); font-size: 15px; text-transform: uppercase; padding: 10px 8px;">${this._t('custCode')}</th>
                            <th style="width: 10%; text-align: left;   color: var(--text-sub); font-size: 15px; text-transform: uppercase; padding: 10px 8px;">${this._t('season')}</th>
                            <th style="width: 15%; text-align: right;  color: var(--text-sub); font-size: 15px; text-transform: uppercase; padding: 10px 8px;">${this._t('rcvQty')}</th>
                            <th style="width: 15%; text-align: right;  color: var(--text-sub); font-size: 15px; text-transform: uppercase; padding: 10px 8px;">${this._t('issQty')}</th>
                            <th style="width: 15%; text-align: right;  color: var(--text-sub); font-size: 15px; text-transform: uppercase; padding: 10px 8px;">${this._t('stkQty')}</th>
                            <th style="width: 13%; text-align: right; color: var(--text-sub); font-size: 15px; text-transform: uppercase; padding: 10px 8px;">${this._t('issRate')}</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${rowsHtml}
                    </tbody>
                </table>
            </div>

            <div class="table-pagination-footer" style="display: flex; justify-content: space-between; align-items: center; margin-top: 10px; padding: 4px 8px;">
                <div style="font-size: 13px; color: var(--text-sub);">
                    Total: <b style="color: #fff;">${this.rawData.length}</b> records
                </div>
                <div style="display: flex; gap: 5px; align-items: center;">
                    <span style="font-size: 13px; color: var(--text-sub); margin-right: 5px;">${this._t('page')} ${this.currentPage} / ${totalPages}</span>
                    ${pageDotsHtml}
                </div>
            </div>
        `;

        this.container.innerHTML = html;

        // Bật hoặc thiết lập lại bộ đếm thời gian chuyển trang tự động
        this.startAutoPlay(totalPages);
    }

    /**
     * Kích hoạt vòng lặp thời gian để tự động nhảy trang
     */
    startAutoPlay(totalPages) {
        this.stopAutoPlay(); // Reset bộ hẹn giờ cũ phòng trường hợp trùng lặp

        if (totalPages <= 1) return; // Nếu chỉ có 1 trang thì không cần chạy xoay tua

        this.autoPlayTimer = setInterval(() => {
            if (this.currentPage >= totalPages) {
                this.currentPage = 1; // Hết số trang thì quay lại trang đầu
            } else {
                this.currentPage++;
            }
            // Gọi lại hàm render để cập nhật màn hình
            this.render(this.rawData);
        }, this.intervalTime);
    }

    /**
     * Dừng chạy ngầm (Sử dụng khi hàm init gọi lại dữ liệu mới hoặc xảy ra lỗi)
     */
    stopAutoPlay() {
        if (this.autoPlayTimer) {
            clearInterval(this.autoPlayTimer);
            this.autoPlayTimer = null;
        }
    }
}