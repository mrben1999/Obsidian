﻿/**
 * wmc.js — FABRIC WAREHOUSE & SUPPLY CHAIN INTELLIGENCE MONITOR
 * Version : 3.1 (API-Ready, Performance Optimized)
 *
 * TÓM TẮT CÁC TỐI ƯU SO VỚI BẢN GỐC:
 *  1) loadDashboardData(): gọi 5 API SONG SONG bằng Promise.allSettled
 *     thay vì await tuần tự -> giảm thời gian tải từ tổng-cộng xuống còn
 *     bằng API chậm nhất.
 *  2) Chặn gọi chồng (re-entrancy guard) để tránh nhiều request cùng lúc
 *     nếu vòng lặp 10 phút kích hoạt trong khi lần tải trước chưa xong.
 *  3) Overlay loading toàn màn hình CHỈ hiện ở lần tải đầu tiên; các lần
 *     tự động refresh sau đó không che UI (tránh chớp màn hình TV wall).
 *  4) Debounce sự kiện resize (150ms) để tránh gọi chart.resize() dồn dập
 *     khi người dùng kéo cửa sổ.
 *  5) Cache đối tượng Intl.DateTimeFormat trong setupClock() thay vì tạo
 *     mới mỗi giây.
 *  6) Dọn toàn bộ code chết (dead/commented-out code) để dễ bảo trì.
 */

import {
    fetchKpiCard,
    fetchFabricStockDashboard,
    fetchStockReport,
    fetchSupplierPerformance,
    fetchIncomingShipments,
    fetchYardCapacity
} from './wmcapi.js';

import {
    setupLanguageDropdown,
    formatNumberByLocale,
    getCurrentLanguage,
    getEchartsLoadingOption
} from './wmchelpers.js';

import StockReportTable from './tables/stockReportTable.js';
import SupplierPerformanceChart from './charts/supplierPerformanceChart.js';
import IncomingShipmentTable from './tables/incomingShipmentTable.js';
import StockDonutChart from './charts/stockDonutChart.js';
import YardCapacityGauges from './charts/YardCapacityGauges.js';

// ------------------------------------------------------------------
// 0. OBJECT TOÀN CỤC — Lưu instance ECharts để tái sử dụng & resize
// ------------------------------------------------------------------
const globalCharts = {};
let countdownSeconds = 10 * 60; // 10 phút

// Quản lý instances của các component bảng/biểu đồ dạng class
let stockReportTableInstance = null;
let supplierPerformanceChartInstance = null;
let incomingShipmentTableInstance = null;
let customerChartInstance = null; // Stock by Customer (YDS) — StockDonutChart
let yardGaugesInstance = null;    // Cụm gauge sức chứa kho/kệ — YardCapacityGauges

// Cờ chống gọi chồng riêng cho vòng refresh 30s của Yard Capacity Gauges
// (độc lập với isDashboardLoading của vòng refresh 10 phút chính, vì API
// này có cache 30s ở backend nên cần chu kỳ refresh nhanh hơn hẳn phần còn lại)
let isYardGaugesLoading = false;

// Cờ chống gọi chồng + đánh dấu lần tải đầu tiên (để show overlay đúng lúc)
let isDashboardLoading = false;
let isFirstLoad = true;

document.addEventListener('DOMContentLoaded', function () {
    initDashboard();
});

/**
 * HÀM KHỞI TẠO TRUNG TÂM (Nhạc trưởng điều phối)
 */
function initDashboard() {
    // BƯỚC 1: KHỞI TẠO HẠ TẦNG VÀ NGÔN NGỮ TRƯỚC (BẮT BUỘC CHẠY ĐẦU TIÊN)
    setupLanguageDropdown();
    setupClock();
    setupCountdown();
    setupFullscreen();
    setupFooterTicker();
    setupResizeEvent();
    setupLanguageChangeObserver(); // Lắng nghe sự kiện đổi ngôn ngữ ngầm

    // BƯỚC 2: SAU KHI ĐA NGÔN NGỮ ĐÃ SẴN SÀNG -> MỚI KHỞI TẠO COMPONENT UI BẢNG
    stockReportTableInstance = new StockReportTable('stockReportDetailTableContainer');
    incomingShipmentTableInstance = new IncomingShipmentTable('incomingShipmentTable');

    // BƯỚC 3: KHỞI TẠO BIỂU ĐỒ VÀ NẠP DỮ LIỆU
    buildChartSkeletons();
    loadDashboardData();

    // BƯỚC 4: Cụm Gauge Sức chứa Kho/Kệ (Yard Capacity) — chu kỳ refresh riêng 30s,
    // độc lập với vòng 10 phút của loadDashboardData() vì backend cache API này
    // chỉ giữ 30s (dữ liệu sức chứa cần "tươi" hơn các số liệu tồn kho tổng quan).
    setupYardCapacityGauges();
}

/* ==========================================================================
   SECTION 1 — KHỞI TẠO KHUNG SƯỜN BIỂU ĐỒ (SKELETONS)
   ========================================================================== */
function buildChartSkeletons() {
    // Customer Donut Chart - STOCK BY CUSTOMER (YDS)
    // Dùng chung class StockDonutChart (charts/stockDonutChart.js) thay vì
    // initChart()/renderCustomerChart() viết tay ngay trong file này —
    // gọn hơn, logic vẽ donut chỉ nằm ở 1 nơi duy nhất trong toàn hệ thống.
    const customerChartContainer = document.getElementById('customerChart');
    if (customerChartContainer) {
        customerChartInstance = new StockDonutChart('customerChart', {
            radius: ['50%', '80%'],
            center: ['32%', '50%'],
            legendRight: '0%',
            legendFontSize: 10,
            centerTotal: { label: 'TOTAL', unit: 'YDS' }
        });
        globalCharts['customerChart'] = customerChartInstance; // Đăng ký resize tự động
    }

    // Material Class Chart Skeleton - TOP 5 MATERIAL CLASS BY STOCK (YDS)
    initChart('materialChart', {
        grid: { left: '2%', right: '4%', top: '18%', bottom: '8%', containLabel: true },
        tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' }, backgroundColor: '#0d2857', borderColor: '#8ba2c1', borderWidth: 1, textStyle: { color: '#ffffff' } },
        legend: { top: '2%', textStyle: { color: '#8ba2c1', fontSize: 10 }, data: ['FA', 'FB', 'IN'], itemWidth: 10, itemHeight: 10 },
        xAxis: { type: 'value', splitLine: { show: false }, axisLabel: { color: '#8ba2c1', fontSize: 10 } },
        yAxis: { type: 'category', data: [], axisLabel: { color: '#8ba2c1', fontSize: 12 }, axisLine: { lineStyle: { color: '#0d2857' } } },
        series: ['FA', 'FB', 'IN'].map((name, index) => {
            const colors = ['#1976d2', '#2e7d32', '#fdd835'];
            return {
                name: name, type: 'bar', stack: 'total', barMaxWidth: 16,
                label: { show: true, fontSize: 9, color: '#fff' },
                itemStyle: { color: colors[index] },
                data: []
            };
        })
    });
    // ĐÃ VÁ (07/2026): materialChart là echarts instance thô (khởi tạo qua initChart(),
    // không phải class riêng như các chart khác) nên trước đây KHÔNG hề gọi showLoading()
    // — panel "TOP 5 MATERIAL CLASS" hiển thị trống trơn suốt lúc chờ dữ liệu, khác hẳn
    // mọi chart khác trên dashboard. Hiện vòng xoay ngay khi vừa khởi tạo skeleton, đồng
    // bộ với cách StockDonutChart/SupplierPerformanceChart tự showLoading() trong constructor.
    if (globalCharts['materialChart']) {
        globalCharts['materialChart'].showLoading(getEchartsLoadingOption());
    }

    // Khởi tạo thực thể cho biểu đồ Hiệu suất Supplier
    const perfContainer = document.getElementById('supplierPerformanceChart');
    if (perfContainer) {
        supplierPerformanceChartInstance = new SupplierPerformanceChart('supplierPerformanceChart');
        globalCharts['supplierPerformance'] = supplierPerformanceChartInstance; // Đăng ký resize tự động
    }

    // Cụm 8 Gauge Rolls A-H: đã chuyển sang dùng component YardCapacityGauges
    // (components/YardCapacityGauges.js), khởi tạo & tải dữ liệu ở setupYardCapacityGauges()
    // thay vì echarts.init() tay + dữ liệu mock như bản trước.

}

/* ==========================================================================
   SECTION 2 — ĐỔ DỮ LIỆU VÀO GIAO DIỆN từ API (TẢI SONG SONG)
   ========================================================================== */
async function loadDashboardData() {
    // Chặn gọi chồng: nếu vòng trước chưa xong mà countdown lại kích hoạt,
    // bỏ qua lần gọi mới để tránh nhiều request/redraw chồng lấp nhau.
    if (isDashboardLoading) {
        console.warn('[WMC System] Bỏ qua request: vòng tải trước chưa hoàn tất.');
        return;
    }
    isDashboardLoading = true;

    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    const currentDynamicDate = `${yyyy}-${mm}-${dd}`;

    const currentWarehouse = 'QVN-A'; // Kho lọc mặc định
    const activeBrand = 'All';        // Nhãn hàng mặc định

    const loadingOverlay = document.getElementById('loading-overlay');
    // Chỉ hiện overlay full-screen ở LẦN TẢI ĐẦU TIÊN.
    // Các lần tự động refresh sau (mỗi 10 phút) không nên che toàn màn hình
    // TV wall — dữ liệu sẽ tự cập nhật êm khi API trả về (giống dashboard
    // thật thường thấy: soft-refresh, không blocking).
    if (loadingOverlay && isFirstLoad) {
        loadingOverlay.style.display = 'flex';
    }

    // Bật trạng thái loading nhẹ cho từng khối, không chặn các khối khác
    if (isFirstLoad) {
        if (stockReportTableInstance && typeof stockReportTableInstance.showLoading === 'function') {
            stockReportTableInstance.showLoading();
        }
        if (supplierPerformanceChartInstance && typeof supplierPerformanceChartInstance.showLoading === 'function') {
            supplierPerformanceChartInstance.showLoading();
        }
        if (incomingShipmentTableInstance && typeof incomingShipmentTableInstance.showLoading === 'function') {
            incomingShipmentTableInstance.showLoading();
        }
    }

    // --- PHÁT LỆNH GỌI 5 API ĐỒNG THỜI (KHÔNG CHẶN NHAU) ---
    const promises = [
        fetchKpiCard(currentDynamicDate, activeBrand),          // [0]
        fetchFabricStockDashboard(currentDynamicDate),          // [1]
        fetchStockReport(currentWarehouse),                     // [2]
        fetchSupplierPerformance(currentWarehouse),              // [3]
        fetchIncomingShipments(currentWarehouse)                 // [4]
    ];

    // Promise.allSettled: mỗi API xử lý độc lập, 1 API lỗi không làm
    // sập toàn bộ dashboard (giữ đúng hành vi try/catch riêng của bản gốc)
    const [kpiResult, stockDashboardResult, stockReportResult, perfResult, shipmentResult] =
        await Promise.allSettled(promises);

    // TỐI ƯU (07/2026): bọc toàn bộ phần xử lý/render sau khi API trả về trong
    // try/finally. Trước đây 1 lỗi runtime bất ngờ ở BẤT KỲ đâu trong khối này
    // (ví dụ bug renderError() đã vá — xem CHANGELOG cuối file) sẽ làm hàm dừng
    // đột ngột, khiến isDashboardLoading không bao giờ được reset về false và
    // loadingOverlay kẹt mãi trên màn hình. finally đảm bảo 2 việc này LUÔN
    // được thực hiện dù có lỗi hay không.
    try {
        // --- [1] KPI CARDS ---
        if (kpiResult.status === 'fulfilled' && kpiResult.value && kpiResult.value.isSuccess) {
            updateKpiCards(kpiResult.value.data);
        } else {
            const msg = kpiResult.status === 'fulfilled' ? kpiResult.value?.message : kpiResult.reason;
            console.warn('Không lấy được dữ liệu KPI Card từ API:', msg);
        }

        // --- [2] CUSTOMER DONUT + MATERIAL CLASS (dữ liệu gộp) ---
        if (stockDashboardResult.status === 'fulfilled' && stockDashboardResult.value && stockDashboardResult.value.isSuccess && stockDashboardResult.value.data) {
            const serverDashboardData = stockDashboardResult.value.data;

            if (customerChartInstance && Array.isArray(serverDashboardData.customerStocks)) {
                customerChartInstance.render(serverDashboardData.customerStocks);
            }

            if (serverDashboardData.materialClassStocks) {
                const categories = serverDashboardData.materialClassStocks.categories || [];
                const seriesDataArray = serverDashboardData.materialClassStocks.seriesDataArray || [];
                renderMaterialClass(categories, seriesDataArray);
            }
        } else {
            const msg = stockDashboardResult.status === 'fulfilled' ? stockDashboardResult.value?.message : stockDashboardResult.reason;
            console.warn('Không lấy được dữ liệu gộp từ API kho NPL:', msg);
            // Trước đây customerChart im lặng giữ trạng thái cũ khi API lỗi; giờ
            // hiện rõ trạng thái lỗi cho người xem TV wall, đồng bộ với các
            // khối khác (StockReportTable, SupplierPerformanceChart...).
            if (customerChartInstance) {
                customerChartInstance.showError(msg);
            }
            // materialChart là echarts thô, không có showError() riêng — nhưng vẫn
            // PHẢI hideLoading(), nếu không vòng xoay đã hiện từ buildChartSkeletons()
            // sẽ đứng yên vĩnh viễn trên màn hình mỗi khi API này lỗi.
            if (globalCharts['materialChart']) {
                globalCharts['materialChart'].hideLoading();
            }
        }

        // --- [3] BÁO CÁO CHI TIẾT TỒN KHO (BẢNG) ---
        if (stockReportResult.status === 'fulfilled' && stockReportResult.value && stockReportResult.value.isSuccess) {
            stockReportTableInstance.render(stockReportResult.value.data);
        } else {
            const msg = stockReportResult.status === 'fulfilled' ? stockReportResult.value?.message : stockReportResult.reason;
            // ĐÃ VÁ BUG (07/2026): trước đây gọi stockReportTableInstance.renderError(msg, callback)
            // — hàm này KHÔNG TỒN TẠI trên StockReportTable (chỉ có showError(msg), không nhận
            // callback retry). Gọi hàm không tồn tại ném TypeError ngay tại đây, làm
            // loadDashboardData() dừng đột ngột giữa chừng -> các bước render còn lại (supplier
            // chart, shipment table) và đặc biệt là lệnh ẩn loading-overlay ở cuối hàm KHÔNG BAO
            // GIỜ chạy tới -> overlay kẹt vĩnh viễn trên màn hình TV wall.
            stockReportTableInstance.showError(msg);
        }

        // --- [4] BIỂU ĐỒ HIỆU SUẤT NHÀ CUNG CẤP (TOP 15) ---
        if (perfResult.status === 'fulfilled' && perfResult.value) {
            if (supplierPerformanceChartInstance) {
                supplierPerformanceChartInstance.render(perfResult.value);
            }
        } else {
            console.error('Lỗi Module Performance Chart:', perfResult.reason);
            if (supplierPerformanceChartInstance) {
                supplierPerformanceChartInstance.showError(perfResult.reason?.message || 'Không thể tải biểu đồ');
            }
        }

        // --- [5] BẢNG GIÁM SÁT HÀNG VẬN CHUYỂN ĐẾN ---
        if (shipmentResult.status === 'fulfilled' && shipmentResult.value) {
            const shipmentResponse = shipmentResult.value;
            if (incomingShipmentTableInstance) {
                if (shipmentResponse.isSuccess) {
                    incomingShipmentTableInstance.render(shipmentResponse.data || []);
                } else {
                    incomingShipmentTableInstance.showError(shipmentResponse.message || 'Response empty');
                }
            }
        } else {
            console.error('Lỗi Module Incoming Shipment Grid:', shipmentResult.reason);
            if (incomingShipmentTableInstance) {
                incomingShipmentTableInstance.showError(shipmentResult.reason?.message || 'Lỗi kết nối');
            }
        }

        // Ghi chú: Cụm Gauge Rolls A-H (Yard Capacity) không còn nằm trong luồng
        // 5-API song song ở đây nữa — chúng có vòng refresh 30s riêng, xem
        // setupYardCapacityGauges() / loadYardCapacityData() bên dưới.
    } finally {
        // Luôn chạy dù khối try phía trên thành công hay ném lỗi bất ngờ —
        // đảm bảo overlay không bao giờ bị kẹt và vòng refresh tiếp theo vẫn
        // được phép chạy (isDashboardLoading reset về false).
        if (loadingOverlay) loadingOverlay.style.display = 'none';
        isFirstLoad = false;
        isDashboardLoading = false;
    }
}

/* ==========================================================================
   SECTION 3 — CÁC HÀM RENDER CHI TIẾT ĐỐI TƯỢNG ĐỘNG
   ========================================================================== */

/**
 * Cập nhật số liệu từ API vào các thẻ KPI định danh trên giao diện TV Wall
 * @param {Object} data - Đối tượng chứa thông tin số liệu trả về từ API KpiCard
 */
function updateKpiCards(data) {
    if (!data) return;

    const setKpiText = (id, value, isRound = false) => {
        const el = document.getElementById(id);
        if (el) {
            let num = parseFloat(value) || 0;
            if (isRound) {
                el.innerText = formatNumberByLocale(Math.round(num), 0);
            } else {
                el.innerText = formatNumberByLocale(num, 0);
            }
        }
    };

    setKpiText('kpiStockQty', data.stockQty);
    setKpiText('kpiStockRolls', data.stockRolls, true);

    setKpiText('kpiLastReceiveQty', data.rcvLastQty);
    setKpiText('kpiTodayReceiveQty', data.rcvTodayQty);

    setKpiText('kpiLastIssueQty', Math.abs(data.issLastQty));
    setKpiText('kpiTodayIssueQty', Math.abs(data.issTodayQty));

    setKpiText('kpiTransitQty', data.qtyInTransit);
    setKpiText('kpiTransitInv', data.invInTransit, true);
}

/**
 * Tên: Top 5 Material Class by Stock
 */
function renderMaterialClass(categories, seriesDataArray) {
    if (!globalCharts['materialChart']) return;

    // Ẩn vòng xoay đã hiện từ lúc khởi tạo skeleton (xem buildChartSkeletons())
    globalCharts['materialChart'].hideLoading();

    globalCharts['materialChart'].setOption({
        yAxis: { data: categories },
        series: seriesDataArray.map((data, idx) => ({ data: data }))
    });
}

/* ==========================================================================
   SECTION 4 — HÀM TIỆN ÍCH HỆ THỐNG GIAO DIỆN
   ========================================================================== */
function initChart(id, option) {
    const dom = document.getElementById(id);
    if (!dom) return;
    const chart = echarts.init(dom);
    chart.setOption(option);
    globalCharts[id] = chart;
    return chart;
}

function setupClock() {
    // Cache formatter theo locale để không tạo mới Intl.DateTimeFormat
    // mỗi giây (Intl.DateTimeFormat khá tốn khi khởi tạo).
    const formatterCache = {};
    const getFormatters = (locale) => {
        if (!formatterCache[locale]) {
            formatterCache[locale] = {
                date: new Intl.DateTimeFormat(locale, { day: '2-digit', month: 'short', year: 'numeric' }),
                time: new Intl.DateTimeFormat(locale, { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false })
            };
        }
        return formatterCache[locale];
    };

    const updateClock = () => {
        const now = new Date();

        const lang = (typeof getCurrentLanguage === 'function')
            ? getCurrentLanguage()
            : (localStorage.getItem('lng') || 'en');

        let locale = 'en-US';
        if (lang === 'vi') locale = 'vi-VN';
        if (lang === 'zh') locale = 'zh-TW';

        const { date: dateFormatter, time: timeFormatter } = getFormatters(locale);

        const dateEl = document.getElementById('currentDate');
        if (dateEl) dateEl.innerText = dateFormatter.format(now);

        const timeEl = document.getElementById('currentTime');
        if (timeEl) timeEl.innerText = timeFormatter.format(now);
    };

    updateClock();
    setInterval(updateClock, 1000);
}

function setupCountdown() {
    setInterval(() => {
        const min = Math.floor(countdownSeconds / 60);
        const sec = countdownSeconds % 60;
        const el = document.getElementById('countdownTimer');
        if (el) el.textContent = `${String(min).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;

        if (countdownSeconds <= 0) {
            countdownSeconds = 10 * 60;
            loadDashboardData(); // Đã có guard isDashboardLoading chống gọi chồng
        } else {
            countdownSeconds--;
        }
    }, 1000);
}

function setupFullscreen() {
    const btnFS = document.getElementById('btnFullscreen');
    if (!btnFS) return;

    btnFS.addEventListener('click', function () {
        const isFS = document.fullscreenElement ||
            document.webkitFullscreenElement ||
            document.mozFullScreenElement ||
            document.msFullscreenElement;

        const el = document.documentElement;

        if (!isFS) {
            if (el.requestFullscreen) el.requestFullscreen();
            else if (el.webkitRequestFullscreen) el.webkitRequestFullscreen();
            else if (el.mozRequestFullScreen) el.mozRequestFullScreen();
            else if (el.msRequestFullscreen) el.msRequestFullscreen();
        } else {
            if (document.exitFullscreen) document.exitFullscreen();
            else if (document.webkitExitFullscreen) document.webkitExitFullscreen();
            else if (document.mozCancelFullScreen) document.mozCancelFullScreen();
            else if (document.msExitFullscreen) document.msExitFullscreen();
        }
    });

    function onFullscreenChange() {
        const isFS = document.fullscreenElement ||
            document.webkitFullscreenElement ||
            document.mozFullscreenElement ||
            document.msFullscreenElement;

        const icon = btnFS.querySelector('i');
        if (icon) {
            icon.className = isFS ? 'fas fa-compress' : 'fas fa-expand';
            btnFS.style.borderColor = isFS ? 'var(--red)' : '#1976d2';
        }

        setTimeout(() => {
            Object.keys(globalCharts).forEach(k => {
                if (globalCharts[k]) globalCharts[k].resize();
            });
        }, 250);
    }

    ['fullscreenchange', 'webkitfullscreenchange', 'mozfullscreenchange', 'MSFullscreenChange']
        .forEach(ev => document.addEventListener(ev, onFullscreenChange));
}

/**
 * Debounce đơn giản: gộp nhiều lần gọi liên tiếp trong khoảng `wait`ms
 * thành 1 lần gọi duy nhất sau khi ngừng bắn sự kiện.
 */
function debounce(fn, wait) {
    let timeoutId = null;
    return function (...args) {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => fn.apply(this, args), wait);
    };
}

function setupResizeEvent() {
    const handleResize = debounce(() => {
        Object.keys(globalCharts).forEach(key => {
            if (globalCharts[key]) globalCharts[key].resize();
        });
    }, 150);

    window.addEventListener('resize', handleResize);
}

/**
 * Cụm Gauge Sức chứa Kho/Kệ (Yard Capacity) — component riêng, tự quản lý
 * việc render 2x4 grid gauge. Khác với 5 API chính của loadDashboardData()
 * (refresh mỗi 10 phút), API này có cache 30s ở backend nên cần vòng refresh
 * riêng, nhanh hơn nhiều.
 *
 * TỐI ƯU so với đoạn code gốc được cung cấp:
 *  - Không tự đăng ký thêm 1 'resize' listener riêng (window.addEventListener)
 *    — thay vào đó đăng ký instance vào globalCharts để dùng chung cơ chế
 *    debounce 150ms đã có ở setupResizeEvent(), tránh gọi resize() dồn dập
 *    khi kéo cửa sổ (giống mọi chart khác trên dashboard).
 *  - Thêm guard isYardGaugesLoading chống gọi chồng nếu 1 lần fetch nào đó
 *    chạy lâu hơn 30s (áp dụng cùng nguyên tắc đã sửa cho loadDashboardData()).
 *  - Dùng fetchYardCapacity() từ wmcapi.js (đã xử lý HTTP error, response rỗng,
 *    chuẩn hóa isSuccess/data/message) thay vì fetch() + .then() thô — đồng bộ
 *    hoàn toàn với cách 5 API còn lại của dashboard đang gọi.
 */
function setupYardCapacityGauges() {
    yardGaugesInstance = new YardCapacityGauges();
    yardGaugesInstance.showLoading();

    // Đăng ký vào globalCharts để tự resize theo cơ chế debounce chung,
    // không cần thêm resize listener riêng cho component này.
    globalCharts['yardGauges'] = yardGaugesInstance;

    loadYardCapacityData(); // Tải lần đầu ngay khi vào trang
    setInterval(loadYardCapacityData, 30000); // Tự động refresh mỗi 30 giây
}

async function loadYardCapacityData() {
    if (isYardGaugesLoading) {
        console.warn('[WMC System] Bỏ qua request Yard Capacity: vòng tải trước chưa hoàn tất.');
        return;
    }
    isYardGaugesLoading = true;

    const currentBrand = localStorage.getItem('selectedBrand') || 'All';

    try {
        // Đồng bộ với 5 API còn lại: dùng fetchYardCapacity (wmcapi.js) thay vì
        // fetch() thô — đã có sẵn xử lý HTTP error, response rỗng, và chuẩn hóa
        // về cùng 1 cấu trúc { isSuccess, data, message } dùng chung toàn hệ thống.
        const apiResponse = await fetchYardCapacity(currentBrand);

        if (yardGaugesInstance) {
            if (apiResponse.isSuccess) {
                yardGaugesInstance.render(apiResponse);
            } else if (typeof yardGaugesInstance.showError === 'function') {
                yardGaugesInstance.showError(apiResponse.message);
            }
        }
    } catch (err) {
        console.error('Lỗi nạp dữ liệu sức chứa kho kệ:', err);
        if (yardGaugesInstance && typeof yardGaugesInstance.showError === 'function') {
            yardGaugesInstance.showError(err.message);
        }
    } finally {
        isYardGaugesLoading = false;
    }
}

function setupFooterTicker() {
    const ticker = document.getElementById('notification-ticker');
    if (!ticker) return;

    const duration = Math.max(ticker.innerText.length * 0.28, 20);
    ticker.style.animation = `tickerAnimation ${duration}s linear infinite`;

    ticker.parentElement.addEventListener('mouseover', () => { ticker.style.animationPlayState = 'paused'; });
    ticker.parentElement.addEventListener('mouseout', () => { ticker.style.animationPlayState = 'running'; });
}

/**
 * Lắng nghe tín hiệu đổi ngôn ngữ từ hệ thống để cập nhật lại giao diện bảng
 */
function setupLanguageChangeObserver() {
    window.addEventListener('wmc-language-changed', function (e) {
        const newLang = e.detail.lang;
        console.log(`[WMC System] Đã nhận tín hiệu đổi ngôn ngữ sang: ${newLang}`);

        if (stockReportTableInstance && stockReportTableInstance.rawData && stockReportTableInstance.rawData.length > 0) {
            stockReportTableInstance.render(stockReportTableInstance.rawData);
        }
    });
}