﻿/**
 * wmchelpers.js - Thư viện tiện ích dùng chung cho Dashboard FJOC.
 * Quản lý: Định dạng số, xử lý ngày tháng, đa ngôn ngữ và thông báo hệ thống.
 */

// ==========================================
// 1. XỬ LÝ SỐ LIỆU & ANIMATION
// ==========================================

/**
 * Trích xuất số từ chuỗi định dạng (loại bỏ dấu phân cách).
 */
export function parseNumberFromText(text, defaultVal = 0) {
    if (text === null || typeof text === 'undefined') return defaultVal;
    const numberString = String(text).replace(/[^\d-]/g, '');
    return numberString ? parseInt(numberString, 10) : defaultVal;
}

/**
 * Định dạng số theo Locale (vi-VN, en-US, zh-TW).
 */
export function formatNumberByLocale(num, digits = null) {
    const lang = getCurrentLanguage();
    const roundedNum = num || 0;
    let locale = lang === 'vi' ? 'vi-VN' : (lang === 'zh' ? 'zh-TW' : 'en-US');

    // Tạo object options động nếu cấu hình digits được truyền vào
    const options = digits !== null ? { minimumFractionDigits: digits, maximumFractionDigits: digits } : {};

    try {
        return new Intl.NumberFormat(locale, options).format(roundedNum);
    } catch (e) {
        // Fallback đơn giản nếu lỗi
        return digits === 0 ? Math.round(roundedNum).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
            : roundedNum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }
}

/**
 * Hiệu ứng chạy số tăng dần (Cubic Out Easing).
 */
export function animateValue(el, start, end, duration = 800, formatter = v => formatNumberByLocale(v)) {
    if (!el) return;
    const safeStart = parseNumberFromText(start);
    const safeEnd = isNaN(end) ? 0 : end;

    if (safeStart === safeEnd) {
        el.textContent = formatter(safeEnd);
        return;
    }

    const startTime = performance.now();
    const delta = safeEnd - safeStart;
    const easeOutCubic = t => 1 - Math.pow(1 - t, 3);

    function frame(now) {
        const t = Math.min(1, (now - startTime) / duration);
        const value = safeStart + delta * easeOutCubic(t);
        el.textContent = formatter(value);
        if (t < 1) requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
}

// ==========================================
// 2. XỬ LÝ NGÀY THÁNG
// ==========================================

export function isDateNotFuture(dateStr) {
    const today = new Date().setHours(0, 0, 0, 0);
    const selected = new Date(dateStr).setHours(0, 0, 0, 0);
    return selected <= today;
}

/**
 * Định dạng ngày tháng dựa theo ngôn ngữ hệ thống được lựa chọn
 * @param {Date|string} date - Đối tượng Date hoặc chuỗi ngày cần định dạng
 * @returns {string} Chuỗi ngày tháng đã định dạng an toàn
 */
export function formatDateByLanguage(date) {
    // 1. Kiểm tra an toàn đối tượng ngày đầu vào
    let dateObj = date;
    if (!(dateObj instanceof Date) || isNaN(dateObj.getTime())) {
        dateObj = new Date(date);
        // Nếu parse vẫn không hợp lệ, fallback về thời gian hiện tại để bảo vệ giao diện TV
        if (isNaN(dateObj.getTime())) {
            dateObj = new Date();
        }
    }

    // 2. Định nghĩa bảng ánh xạ ngôn ngữ an toàn
    const locales = {
        'vi': 'vi-VN',
        'en': 'en-US',
        'zh': 'zh-TW',
        'tw': 'zh-TW'
    };

    // 3. Lấy ngôn ngữ hiện tại và kiểm tra fallback chống giá trị undefined/null
    let lang = 'en';
    try {
        if (typeof getCurrentLanguage === 'function') {
            lang = getCurrentLanguage() || 'en';
        } else {
            // Đọc trực tiếp từ localStorage nếu hàm helper không tồn tại trong scope
            lang = localStorage.getItem('currentLanguage') || 'en';
        }
    } catch (e) {
        console.warn("Không thể lấy ngôn ngữ hệ thống, tự động fallback về 'en':", e);
    }

    // Làm sạch chuỗi ký tự ngôn ngữ (chuyển về chữ thường, cắt khoảng trắng)
    lang = String(lang).toLowerCase().trim();

    // 4. Cấu hình định dạng hiển thị chi tiết
    const options = {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    };

    // 5. Thực thi bọc trong block try-catch để an toàn tuyệt đối cho TV Wall
    try {
        const localeCode = locales[lang] || 'en-US';
        return new Intl.DateTimeFormat(localeCode, options).format(dateObj);
    } catch (error) {
        console.error("Lỗi cấu hình Intl.DateTimeFormat:", error);
        // Khôi phục hiển thị thô dạng vi-VN nếu cấu hình Intl bị crash
        return dateObj.toLocaleDateString('vi-VN');
    }
}

// ==========================================
// 3. CẤU HÌNH HỆ THỐNG & ĐA NGÔN NGỮ
// ==========================================

export function getCurrentLanguage() {
    return document.documentElement.lang || 'en';
}

function setCookie(name, value, days) {
    let expires = "";
    if (days) {
        const date = new Date();
        date.setTime(date.getTime() + (days * 86400000));
        expires = "; expires=" + date.toUTCString();
    }
    document.cookie = `${name}=${value || ""}${expires}; path=/`;
}

/**
 * Thiết lập lưu vết trạng thái ngôn ngữ khi chọn trên Dropdown (Hỗ trợ định dạng Client)
 */
/**
 * Hàm tiện ích mã hóa nhanh các ký tự HTML nhạy cảm
 */
export function escapeHtml(str) {
    if (!str) return '';
    return str
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

export function setupLanguageDropdown() {
    const langItems = document.querySelectorAll('.language-dropdown .dropdown-menu a, .dropdown-item[data-lang]');
    const currentLangImg = document.getElementById('currentLangFlag');

    // Map ảnh cờ tương ứng với mã ngôn ngữ để cập nhật UI lập tức
    const flagSources = {
        'vi': '/assets/images/auth/flag-vi.svg',
        'en': '/assets/images/auth/flag-en-us.svg',
        'zh': '/assets/images/auth/flag-tw.svg'
    };

    // BƯỚC 1: Khôi phục ngôn ngữ từ localStorage nếu có sẵn (Tránh bị Server ghi đè mặc định)
    const savedLng = localStorage.getItem('lng');
    if (savedLng && currentLangImg && flagSources[savedLng]) {
        const currentSrc = (currentLangImg.getAttribute('src') || '').toLowerCase();
        if (!currentSrc.includes(`flag-${savedLng}`)) {
            currentLangImg.setAttribute('src', flagSources[savedLng]);
        }
    }

    // BƯỚC 2: Bắt sự kiện click chọn ngôn ngữ mới
    langItems.forEach(item => {
        item.addEventListener('click', function (e) {
            const selectedLang = this.getAttribute('data-lang');
            if (!selectedLang) return;

            // 1. Lưu cấu hình xuống Client Storage
            localStorage.setItem('lng', selectedLang);

            // 2. Cập nhật trực quan Icon Flag ngay lập tức trên UI
            if (currentLangImg && flagSources[selectedLang]) {
                currentLangImg.setAttribute('src', flagSources[selectedLang]);
            }

            // === [ĐOẠN CẦN BỔ SUNG Ở ĐÂY]: Phát tín hiệu ra toàn hệ thống Dashboard WMC ===
            // Tín hiệu này giúp bảng stockReportTable nhận biết để dịch ngay lập tức trước khi chuyển trang (hoặc chạy ngầm)
            const langEvent = new CustomEvent('wmc-language-changed', {
                detail: { lang: selectedLang }
            });
            window.dispatchEvent(langEvent);
            // ==============================================================================

            // 3. ĐIỀU HƯỚNG SERVER ĐỒNG BỘ (Giữ nguyên logic của anh)
            const currentHref = this.getAttribute('href');
            if (!currentHref || currentHref === '#' || currentHref === 'javascript:void(0);') {
                e.preventDefault();
                const url = new URL(window.location.href);

                // Đổi sang 'culture' để ASP.NET Core Localization nhận diện chính xác
                url.searchParams.set('culture', selectedLang);

                window.location.href = url.href;
            }
        });
    });

    // BƯỚC 3: Chỉ ghi nhận từ ảnh cờ mặc định của Server khi Client HOÀN TOÀN chưa từng chọn ngôn ngữ
    if (!savedLng && currentLangImg) {
        const currentSrc = (currentLangImg.getAttribute('src') || '').toLowerCase();
        if (currentSrc.includes('flag-vi') || currentSrc.includes('vi-vn')) {
            localStorage.setItem('lng', 'vi');
        } else if (currentSrc.includes('flag-tw') || currentSrc.includes('zh-tw') || currentSrc.includes('flag-zh')) {
            localStorage.setItem('lng', 'zh');
        } else if (currentSrc.includes('flag-en') || currentSrc.includes('en-us')) {
            localStorage.setItem('lng', 'en');
        }
    }
}

// ==========================================
// 5. TRẠNG THÁI LOADING DÙNG CHUNG (ECharts + Bảng HTML)
// ==========================================
// Trước 07/2026, mỗi chart/bảng trên dashboard tự định nghĩa 1 kiểu loading
// riêng — ECharts thì dùng spinner nội bộ + text tuỳ ý ("Loading Data...",
// "Loading..."), 2 bảng HTML thì dùng Bootstrap `spinner-border` (hình dạng,
// kích thước phụ thuộc CSS Bootstrap, không liên quan gì tới spinner của
// ECharts) + text riêng ("Loading shipments...", "Loading data...") — thậm
// chí có chart (Material Class) KHÔNG hiện gì cả khi đang tải. Kết quả: nhìn
// dashboard thấy 3-4 kiểu loading khác nhau cùng lúc trên cùng 1 màn hình TV.
//
// Từ đây, TOÀN BỘ trạng thái loading trên dashboard dùng ĐÚNG 1 kiểu vòng
// tròn xoay (spinner ring), không kèm text — dù component đó vẽ bằng ECharts
// (canvas) hay render bằng innerHTML (DOM). Token màu sắc + 2 hàm dưới đây là
// nguồn DUY NHẤT; component KHÔNG được tự định nghĩa lại spinner/text riêng.

/**
 * Bảng màu/kích thước loading dùng chung. Nếu cần đổi tông màu hoặc cỡ vòng
 * xoay cho toàn dashboard, chỉ sửa ở đây — không sửa rải rác trong từng file.
 */
export const WMC_LOADING_THEME = {
    color: '#29b6f6',                          // Màu cung xoay (arc) của spinner
    trackColor: 'rgba(139, 162, 193, 0.25)',    // Màu vòng nền tĩnh (track) phía sau cung xoay
    maskColorDefault: 'rgba(4, 20, 50, 0.7)',   // Mask cho chart/bảng cỡ lớn (che rõ toàn khối)
    maskColorSubtle: 'rgba(4, 20, 50, 0.4)',    // Mask nhạt hơn cho ô nhỏ (vd: từng gauge trong lưới 2x4)
    spinnerSize: 30,                            // Đường kính vòng xoay (px)
    spinnerBorderWidth: 3                       // Độ dày viền vòng xoay (px)
};

/**
 * Trả về option chuẩn cho echarts.showLoading() — dùng cho MỌI chart ECharts
 * trên dashboard (StockDonutChart, SupplierPerformanceChart, YardCapacityGauges,
 * và cả materialChart — chart khởi tạo thô bằng echarts.init() trong wmc.js).
 *
 * text luôn là '' (không hiện chữ) để CHỈ hiện đúng 1 vòng tròn xoay, đồng
 * nhất tuyệt đối với spinner CSS dùng cho bảng HTML (getLoadingHtml bên dưới).
 * spinnerRadius/lineWidth được tính từ cùng token spinnerSize/spinnerBorderWidth
 * để 2 loại spinner (canvas ECharts và CSS DOM) có kích thước gần như nhau.
 *
 * @param {Object} [overrides] - Override có chủ đích khi thật sự cần khác biệt
 *        (vd: gauge nhỏ dùng mask nhạt hơn: { maskColor: WMC_LOADING_THEME.maskColorSubtle })
 * @returns {Object} Object truyền thẳng vào chart.showLoading(...)
 */
export function getEchartsLoadingOption(overrides = {}) {
    return {
        text: '',
        color: WMC_LOADING_THEME.color,
        textColor: WMC_LOADING_THEME.trackColor,
        maskColor: WMC_LOADING_THEME.maskColorDefault,
        zlevel: 0,
        spinnerRadius: (WMC_LOADING_THEME.spinnerSize - WMC_LOADING_THEME.spinnerBorderWidth) / 2,
        lineWidth: WMC_LOADING_THEME.spinnerBorderWidth,
        ...overrides
    };
}

let _wmcSpinnerStyleInjected = false;

/**
 * Chèn 1 lần duy nhất thẻ <style> định nghĩa spinner CSS dùng chung (.wmc-spinner)
 * vào <head>. Idempotent — gọi nhiều lần chỉ chèn đúng 1 lần.
 */
function _ensureSpinnerStyleInjected() {
    if (_wmcSpinnerStyleInjected || document.getElementById('wmc-spinner-style')) {
        _wmcSpinnerStyleInjected = true;
        return;
    }
    const styleTag = document.createElement('style');
    styleTag.id = 'wmc-spinner-style';
    styleTag.textContent = `
        @keyframes wmc-spin { to { transform: rotate(360deg); } }
        .wmc-spinner {
            display: inline-block;
            width: ${WMC_LOADING_THEME.spinnerSize}px;
            height: ${WMC_LOADING_THEME.spinnerSize}px;
            border: ${WMC_LOADING_THEME.spinnerBorderWidth}px solid ${WMC_LOADING_THEME.trackColor};
            border-top-color: ${WMC_LOADING_THEME.color};
            border-radius: 50%;
            animation: wmc-spin 0.8s linear infinite;
        }
    `;
    document.head.appendChild(styleTag);
    _wmcSpinnerStyleInjected = true;
}

/**
 * Trả về HTML vòng xoay chuẩn — dùng cho MỌI bảng render bằng innerHTML
 * (StockReportTable, IncomingShipmentTable...). Đây là spinner CSS tự viết
 * (.wmc-spinner), KHÔNG dùng class `spinner-border` của Bootstrap nữa — vì
 * kích thước/độ dày viền của Bootstrap phụ thuộc bản CSS đang load, không
 * đảm bảo khớp với spinner bên ECharts. Cùng 1 token màu + kích thước với
 * getEchartsLoadingOption() ở trên nên nhìn giống hệt nhau dù chart hay bảng.
 *
 * @param {string} [message] - Text tuỳ chọn hiển thị dưới vòng xoay (nên để
 *        trống hoặc rất ngắn — trọng tâm là vòng xoay, không phải chữ).
 * @param {Object} [options]
 * @param {string} [options.padding='30px'] - Padding tổng thể của khối loading
 * @returns {string} Chuỗi HTML sẵn sàng gán vào container.innerHTML
 */
export function getLoadingHtml(message, options = {}) {
    _ensureSpinnerStyleInjected();
    const padding = options.padding || '30px';
    const messageHtml = message
        ? `<div style="font-size:12px; margin-top:8px; color:${WMC_LOADING_THEME.trackColor};">${escapeHtml(message)}</div>`
        : '';

    return `
        <div style="text-align:center; padding: ${padding};">
            <span class="wmc-spinner"></span>
            ${messageHtml}
        </div>
    `;
}

// ==========================================
// 6. ĐIỀU KHIỂN UI (DATEPICKER & MESSAGES)
// ==========================================

export function setupDatePicker() {
    const dateLabel = document.querySelector('.date-label[for="date-filter"]');
    const dateInput = document.getElementById('date-filter');

    if (dateLabel && dateInput) {
        dateLabel.addEventListener('click', () => {
            try { dateInput.showPicker(); } catch (e) { console.warn(e); }
        });
    }

    if (dateInput) {
        dateInput.addEventListener('change', function () {
            if (!this.value) return;
            const url = new URL(window.location.href);
            url.searchParams.set('date', this.value);
            window.history.pushState({}, '', url.href);
            // Kích hoạt sự kiện để main.js nhận biết ngày đã đổi
            window.dispatchEvent(new CustomEvent('dateChanged', { detail: this.value }));
        });
    }
}

export function showMessage(response, type = 'error') {
    const lang = getCurrentLanguage();
    const message = response?.message || (type === 'error' ?
        (lang === 'vi' ? "Lỗi hệ thống!" : "System Error!") : "Success!");

    if (typeof toastr !== 'undefined') {
        toastr.options = { "closeButton": true, "progressBar": true, "positionClass": "toast-top-right" };
        toastr[type](message);
    } else {
        alert(`${type.toUpperCase()}: ${message}`);
    }
}

export function handleApiError(error) {
    console.error("FJOC API Error:", error);
    showMessage({ message: error.message }, 'error');
}

export function makeSafeId(name, fallback) {
    return (name && String(name).replace(/[^a-zA-Z0-9]/g, '-')) || fallback;
}

/**
 * Hàm thực hiện hiệu ứng nhảy số và định dạng hiển thị.
 * Hỗ trợ tự động nhận diện dữ liệu kiểu văn bản hoặc số; số chữ số thập phân
 * được suy ra tự động dựa trên ID của element (xem isDecimalType bên dưới).
 */
export function updateElementWithAnimation({ id, value, suffix = '', prefix = '', isText = false }) {
    const el = document.getElementById(id);
    if (!el) return;

    // 1. Kiểm tra nếu giá trị là text hoặc được chỉ định là text
    // Chúng ta kiểm tra nếu value không phải là số hoặc isText được set là true
    if (isText || typeof value === 'string' && isNaN(parseFloat(value))) {
        el.textContent = `${prefix}${value}${suffix}`;
        return;
    }

    // 2. Chuyển đổi value về kiểu số để đảm bảo tính toán chính xác
    const numericValue = parseFloat(value);
    if (isNaN(numericValue)) {
        el.textContent = `${prefix}${value}${suffix}`;
        return;
    }

    // 3. Xác định số chữ số thập phân dựa trên loại dữ liệu (logic từ ID)
    let decimals = 0;
    const lowerId = id.toLowerCase();
    const isDecimalType = [
        'percent', 'rate', 'efficiency', 'value',
        'workerpersent', 'hours', 'cmt'
    ].some(key => lowerId.includes(key));

    if (isDecimalType) {
        decimals = 1;
    }

    // 4. Trường hợp đặc thù: Hiển thị tĩnh (không animate)
    if (lowerId.includes('per-worker')) {
        el.textContent = `${prefix}${formatNumberByLocale(numericValue.toFixed(1))}${suffix}`;
        return;
    }

    // 5. Thực hiện hiệu ứng nhảy số cho dữ liệu numeric
    animateValue(el, el.textContent, numericValue, 800, v => {
        const num = parseFloat(v);
        const formatted = formatNumberByLocale(decimals > 0 ? num.toFixed(decimals) : Math.round(num));
        return `${prefix}${formatted}${suffix}`;
    });
}